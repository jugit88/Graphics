/*
 *  Homework 2
 *
 *  Draw a few 3d objects. Includes a rocket, spere, and cylinder.
 *
 *  Key bindings:
 *  0,1,2      Toggle between orthogonal(0),perspective(1),first person perspective(2)
 *  +/-        Changes field of view for perspective
 *  b/B        Toggle axes
 *  arrows     Change view angle(for perspective and orthogonal ONLY)
 *  PgDn/PgUp  Zoom in and out
 *  a/w/s/d    move left/move in/move out/move right in first person perspective     
 *  4          Reset view angle
 *  ESC        Exit
 *  
 */